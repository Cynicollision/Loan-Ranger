/** Automatically generated file. DO NOT MODIFY */
package vast.loanranger;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}